#include <stdio.h>
#include <stdlib.h>

#include "KuiperSolver.h"

/*********** Compile+Link+Run at Unix/Linux terminal *****************
 * Compile+Link:   $ gcc KuiperPairSolver.c main.c -o Kuiper -lm
 *           or    $ g++ KuiperPairSolver.c main.c -o Kuiper
 * Run:            $ ./Kuiper 0.05 100  1  1  2.45
 *                 $ ./Kuiper 0.05 100  1  2  2.45 
 *                 $ ./Kuiper 0.05 100  2  1  2.45 >> test.txt
 *                 $ ./Kuiper 0.05 100  2  2  2.45 >> test.txt
 * 
 * Note that the initial value is important for the iteration and our
 * suggestions are as follows:
 *    V_n test, direct iterative method, guess in (0.5, 2.5)
 *    V_n test, Newton iterative method, guess in (1.1, 2.5)
 *    V_{n,n} test, direct iterative method, guess in (2.4, 2.6)
 *    V_{n,n} test, direct iterative method, guess in (2.2, 2.6)
 *  optional guess for all of most applications, guess = 2.45
 *  Newton iterative method works well for both V_n and V_{n,n} test  
 * *******************************************************************/
 
void PrintArray1d(double a[], unsigned size, const char* arrayname)
{
   printf("%s = [", arrayname);
   for(int i = 0; i < size; i++){
	   printf("%.4f", a[i]);
	   if(i < size -1)
			printf(",");
	   else
			printf("];\n");
   }
}

int main(int argc, char* argv[])
{
	double   alpha = atof(argv[1]); // 0.05
	unsigned n     = atoi(argv[2]); // 100
	unsigned type  = atoi(argv[3]); // 1 for V_n and 2 for V_{n,n} test
	unsigned method= atoi(argv[4]); // 1 for Direct and 2 for Newton iterative method
	double   guess = atof(argv[5]); // 2.4 for V_n and V_{n.n}
	
	CheckProbabity(alpha);
	
	KuiperPair sol = KuiperPairSolver(guess, alpha, n, type, method);
    printf("alpha = %.2f, n = %d, guess = %.4f\n", alpha, n, guess);    
 
    if(type == 1){
		printf("V_n test, ");
		if( method == 1){
			printf("Directive Iterative Method\n");
		}else{
			printf("Newton's Iterative Method\n");
		}
		printf("c = %.4f (critical value)\n", sol.c);
        printf("v = %.4f (upper tail quantile)\n", sol.v);
        
		double alpha_list[10] = {0.693, 0.528, 0.377, 0.252, 0.158,
		                         0.093, 0.052, 0.027, 0.0135, 0.0063};
		printf("TABLE I for the  $V_n$-test by Kuiper 1962, \n critical value c,   quantile v,         alpha \n");
		for(int i = 0; i < 10; i++){
			sol = KuiperPairSolver(guess, alpha_list[i], 10, type, method); // n = 10
			printf("\t %.2f, \t\t %.4f, \t %.4f\n", 
		          sol.c, sol.v, alpha_list[i]);
		} 
		printf("\n");
	}else{
		printf("V_{n,n} test, ");
		if( method == 1){
			printf("Directive Iterative Method\n");
		}else{
			printf("Newton's Iterative Method\n");
		}
		printf("c = %.4f (critical value)\n", sol.c);
        printf("v = %.4f (upper tail quantile)\n", sol.v);
		printf("\n");
		double n_list[10] = {10, 20, 30, 40, 100, 1e+8};
		double alpha_list[10] = {0.10, 0.09, 0.08, 0.07, 0.06, 
			                     0.05, 0.04, 0.03, 0.02, 0.01};
		guess = 2.4;  // Attention, please!
		printf("TABLE III for the pair (c, v) of  $V_{n,n}$-test by Kuiper 1962, Newton's method for n = 10, 20, 30, 40, 200, infty\n");
		for(int i = 0; i < 10; i++){
			printf("alpha = %.2f  ", alpha_list[i]);
			for(int j = 0; j < 6; j++){
				sol = KuiperPairSolver(guess, alpha_list[i], n_list[j], type, 2); // Newton's method
				printf("(%.4f, %.4f)", sol.c, sol.v);
				if( j == 5) 
					printf("\n");
				else
					printf(", ");
			}
		}  
	}
	
	printf("\nKuiper's Upper Tail Quantile and Lower Tail Quantile in V_n test, ");
	printf("with element (utq(a), ltq(1-a))\n");
	const int M = 5;
	const int N = 7;
	double AlphaUtq[M]= {0.10, 0.05, 0.02, 0.01, 0.005};
	double AlphaLtq[M]= {0.90, 0.95, 0.98, 0.99, 0.995};
	double utq[M][N];
	double ltq[M][N];
	unsigned capacity[N] = {10, 20, 30, 40, 100, 180, 500};
	printf("n = ");
	for(int j = 0; j < N; j++) printf("%d, ", capacity[j]); 
	printf("\n");
	printf("For alpha_utq + alpha_ltq = 1.0, we have the property utq(a) = ltq(1-a): \n");
	for(int i = 0; i < M; i++){
		printf("a = %.3f, 1-a = %.3f: ", AlphaUtq[i], AlphaLtq[i]);
		for(int j = 0; j < N; j++){
			utq[i][j]  = KuiperUTQ(AlphaUtq[i], capacity[j]);
			ltq[i][j]  = KuiperLTQ(AlphaLtq[i], capacity[j]);
			printf("(%.4f, %.4f)", utq[i][j], ltq[i][j]);
			if(j <= N-2) printf(", ");
		}
		printf("\n");		
	}
	
	
	printf("\nCheck the inverse CDF of Kuiper's V_n statistic, \n");
	unsigned sample_capacity = n;	
	const unsigned size = 80; 	
	double y[size]; // y  = Pr(V <= v)
    double v[size];
    double delta = 1.0/size;
    for(int i = 0; i < size; i++){
		y[i] = i*delta; // y  = Pr(V <= v)
		//CheckProbabity(y[i]);
		v[i] = KuiperInvCDF(y[i], sample_capacity); // v = InvCDF(y)
    }
    printf("sample capacity n = %d\n", sample_capacity);
    printf("there are size = %d points on the curve\n", size);
    printf("\nHint, y = Pr( V_n <= v) = CDF(v), v = InvCDF(y)\n");
    PrintArray1d(y, size, "y"); printf("\n");
    PrintArray1d(v, size, "v");
    
    
    printf("\nYou can use (v, y) to draw the curve of CDF");
    printf(" for the given sample capasity n if size is large enough!\n");
    printf("You can use (y, v) to draw the curve of InvCDF");
    printf(" for the given sample capasity n if size is large enough!\n");
	return 0;
}

