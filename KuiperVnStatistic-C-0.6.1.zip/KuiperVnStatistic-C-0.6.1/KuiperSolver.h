#include <math.h>
#include <stdbool.h>

typedef struct{
	double  c; // critical value,  \alpha = \Pr(\sqrt{n}V_n>c}
	double  v; // quantile for upper tail probability, v = c/sqrt{n}
}KuiperPair;

void CheckProbabity(double alpha);

typedef double (*Ptr2Fun)(double, double, unsigned); // for f(c, alpha, n) 
typedef double (*Ptr2FunUpdate)(Ptr2Fun f, double guess, double alpha, unsigned n); 
typedef double (*Ptr2FunDist)(double, double);

double FunA1cn(double c, unsigned n);
double FunA2cn(double c, unsigned n);
double FunFnlm1(double c, double alpha, unsigned n);
double FunFnlm2(double c, double alpha, unsigned n);
double FunFctm1(double c, double alpha, unsigned n);
double FunFctm2(double c, double alpha, unsigned n);


double UpdateMethodDirect(Ptr2Fun f, double c, double alpha, unsigned n);
double UpdateMethodNewton(Ptr2Fun f, double c, double alpha, unsigned n);

double Distance(double x, double y);
double FunGamma(unsigned n);
KuiperPair KuiperPairSolver(double guess, double alpha, unsigned n, int type, int method);

/*********************** Attention, please! *********************
* KuiperUTQ(x, n) is equivalent to KuiperLTQ(1-x, n)
*****************************************************************/
double KuiperUTQ(double upper_tail_prob, unsigned n);  
double KuiperLTQ(double lower_tail_prob, unsigned n); 

/*********************** Attention, please! *********************
* KuiperInvCDF(x, n) is equivalent to KuiperLTQ(x, n) 
*****************************************************************/
double KuiperInvCDF(double prob, unsigned n); // prob is in [0,1)








