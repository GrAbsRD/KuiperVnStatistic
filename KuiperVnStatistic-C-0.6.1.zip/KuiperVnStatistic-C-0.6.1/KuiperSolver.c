#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "KuiperSolver.h"

void CheckProbabity(double alpha)
{
	if(alpha < 0.0 || alpha > 1.0){
		printf("Input error, it is not probability\n");
        exit(0);
	}
}

/***************** Solving the Fixed-Point *******************/
double FixedPointSolver(
	Ptr2FunUpdate T, 
	Ptr2Fun f, 
	Ptr2FunDist d, // the implementation is the function Distance 
    double precision, double guess, double alpha, unsigned n)
{
	double improve = T(f, guess, alpha, n);
	while( d(guess, improve) >= precision)
	{
		guess = improve;
		improve = T(f, guess, alpha, n);		
	}
	return improve;	
}

/***************** Calculating the distance ******************/ 
double Distance(double x, double y)
{
	double dist = fabs(x - y);
	return dist;	
}


/*********** Auxiliary procedures **********************/
double FunA1cn(double c, unsigned n)
{
	double A1 = -2 +  8*c/sqrt(n) +  8*c*c -  32*c*c*c/(3*sqrt(n));
	return A1;	
}

double FunA2cn(double c, unsigned n)
{
	double A2 = -2 + 32*c/sqrt(n) + 32*c*c - 512*c*c*c/(3*sqrt(n));
	return A2;	
}


/*******  for V_n test, direct iterative method  ********/
double FunFctm1(double c, double alpha, unsigned n)
{
	double A1 = FunA1cn(c, n);
	double A2 = FunA2cn(c, n);
	double y = sqrt((log(A1 + A2*exp(-6*c*c)) - log(alpha))/2);
	return y;	
}

/*******  for V_n test, Newton iterative method  ********/
double FunFnlm1(double c, double alpha, unsigned n)
{
    double A1 = FunA1cn(c, n);
    double A2 = FunA2cn(c, n);
    double y = 2*c*c + log(alpha) - log(A1 + A2*exp(-6*c*c));
    return y;
}

/*******  for V_{n,n} test, direct iterative method  ********/
double FunFctm2(double c, double alpha, unsigned n)
{
	double x = c*c;
    double U1 = 2*(2*x -1) -    x*(2*x -7)/(6*n) - exp(x)/(6*n);
    double U2 = 2*(8*x -1) -  2*x*(8*x-7)/(3*n);
    double y = sqrt(log(U1 + U2*exp(-3*x)) - log(alpha));
    return y;
}

/*******  for V_{n,n} test, Newton's iterative method  ********/
double FunFnlm2(double c, double alpha, unsigned n)
{
	double x = c*c;
    double U1 = 2*(2*x -1) -    x*(2*x -7)/(6*n) - exp(x)/(6*n);
    double U2 = 2*(8*x -1) -  2*x*(8*x-7)/(3*n);
    double y  = x + log(alpha) - log(U1 + U2 * exp(-3*x));
    return y;	
}

/************* Updating Mapping *********************/
double UpdateMethodDirect(Ptr2Fun f_ctm, double c, double alpha, unsigned n)
{
	double  u = f_ctm(c, alpha, n);  // f_ctm is a contractive map;
	return  u;	
}
	
double UpdateMethodNewton(Ptr2Fun f_nlm, double c, double alpha, unsigned n)
{
  double h = 1e-5;
  double slope = (f_nlm(c+h, alpha, n) - f_nlm(c, alpha, n))/h;
  double c_new = c - f_nlm(c, alpha, n)/slope;
  return c_new;
}


/******************* Sovling the Kuiper's Pair ********************/
KuiperPair KuiperPairSolver(double guess, double alpha, unsigned n, int type, int method)
{
	Ptr2FunUpdate T;
	Ptr2Fun f;
	
	/* Direct iterative for Kuiper's $V_n$-test */
	if((method == 1) && (type == 1)) {
		T = UpdateMethodDirect;
		f = FunFctm1; // $f_{ctm1}$ 
	}
	
	/* Newton's iterative for Kuiper's $V_n$-test */
	if((method == 2) &&  (type == 1)) {
		T = UpdateMethodNewton;
		f = FunFnlm1; // $f_{nlm1}$
	}
	
	/* Directive iterative for Kuiper's $V_{n,n}$-test */
	if((method == 1) && (type == 2)) {		
		T = UpdateMethodDirect;
		f = FunFctm2; // $f_{ctm2}$
	}
	
	/* Newton's iterative for Kuiper's $V_{n,n}$-test */
	if((method == 2) && (type == 2)) {		
		T = UpdateMethodNewton;
		f = FunFnlm2; // $f_{nlm2}$
	}
	double  epsilon = 1e-5;
	Ptr2FunDist d = Distance;		
    double c = FixedPointSolver(T, f, d, epsilon, guess, alpha, n);
    double v = c/sqrt(n);	
	KuiperPair sol = {c, v};	
	return sol;
}

/****** for the modified Kuiper's statistic in Kuiper's Test ****/
double FunGamma(unsigned n)
{
	double gamma = 1.0 + 0.155/sqrt(n) + 0.24/n;
	return gamma;
}

/*********************** Attention, please! *********************
* KuiperUTQ(x, n) is equivalent to KuiperLTQ(1-x, n)
*****************************************************************/
double KuiperLTQ(double lower_tail_prob, unsigned n)
{
	if(lower_tail_prob <= 1e-4) {return 0.0;}
	
	double guess = 2.45;
	const int type = 1;
	const int method = 2;
	double utp = 1.0 - lower_tail_prob;
	KuiperPair sol = KuiperPairSolver(guess,utp,n,type,method);
    return sol.v;	
}

/*********************** Attention, please! *********************
* KuiperUTQ(x, n) is equivalent to KuiperLTQ(1-x, n)
*****************************************************************/
double KuiperUTQ(double upper_tail_prob, unsigned n)
{
	if(upper_tail_prob >= 1.0 - 1e-4) {return 0.0;}
	
	Ptr2FunUpdate  T = UpdateMethodNewton;
	Ptr2Fun        f = FunFnlm1;
	double       eps = 1e-5;
	Ptr2FunDist    d = Distance;
	double     guess = 2.45;
	double c = FixedPointSolver(T,f,d,eps,guess,upper_tail_prob,n);
	double utq = c/sqrt(n); // upper tail quantile
	return utq;	
}

double KuiperInvCDF(double prob, unsigned n)
{
	// double x = KuiperLTQ(prob, n) is OK
	double x = KuiperUTQ(1.0 - prob, n); 	
    return x;	
}



